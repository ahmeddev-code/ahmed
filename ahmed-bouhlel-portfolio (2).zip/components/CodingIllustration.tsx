
import React from 'react';

const CodingIllustration = () => {
  return (
    <div className="relative w-full max-w-[500px] h-[400px] flex items-center justify-center">
      {/* Background Glow */}
      <div className="absolute inset-0 bg-scientific-500/20 blur-[80px] rounded-full animate-pulse" />
      
      <svg viewBox="0 0 400 300" xmlns="http://www.w3.org/2000/svg" className="w-full h-full relative z-10 drop-shadow-2xl">
        {/* Defs for gradients and clips */}
        <defs>
          <linearGradient id="screenGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="rgba(255, 255, 255, 0.6)" />
            <stop offset="100%" stopColor="rgba(255, 255, 255, 0.3)" />
          </linearGradient>
          <linearGradient id="bodyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#212427" /> 
            <stop offset="100%" stopColor="#111315" />
          </linearGradient>
          <clipPath id="screenClip">
            <rect x="100" y="80" width="200" height="130" rx="8" />
          </clipPath>
        </defs>

        {/* Laptop Base */}
        <path d="M60 250 L340 250 L320 220 L80 220 Z" fill="#3e464e" />
        <path d="M80 220 L320 220 L320 215 L80 215 Z" fill="#525c66" />

        {/* Character Body - Shark Gray */}
        <path d="M140 280 C140 220, 260 220, 260 280 L260 300 L140 300 Z" fill="url(#bodyGrad)" className="animate-bob" />
        {/* Character Head - Shark Gray */}
        <circle cx="200" cy="170" r="35" fill="#212427" className="animate-bob" />

        {/* Laptop Screen - Glassmorphism */}
        <rect x="95" y="75" width="210" height="140" rx="10" fill="rgba(33, 36, 39, 0.9)" stroke="rgba(255,255,255,0.2)" strokeWidth="2" />
        
        {/* Screen Content Container */}
        <g clipPath="url(#screenClip)">
            {/* Code Lines - Animated */}
            <g className="animate-code-scroll">
                {/* Block 1 */}
                <rect x="110" y="90" width="60" height="6" rx="2" fill="#0066CC" opacity="0.8" />
                <rect x="110" y="105" width="120" height="4" rx="1" fill="#9197A0" opacity="0.5" />
                <rect x="110" y="115" width="100" height="4" rx="1" fill="#9197A0" opacity="0.5" />
                <rect x="130" y="125" width="80" height="4" rx="1" fill="#9197A0" opacity="0.5" />
                
                {/* Block 2 */}
                <rect x="110" y="145" width="50" height="6" rx="2" fill="#66A3FF" opacity="0.8" />
                <rect x="130" y="160" width="140" height="4" rx="1" fill="#9197A0" opacity="0.5" />
                <rect x="130" y="170" width="110" height="4" rx="1" fill="#9197A0" opacity="0.5" />

                {/* Block 3 */}
                <rect x="110" y="190" width="70" height="6" rx="2" fill="#0066CC" opacity="0.8" />
                <rect x="110" y="205" width="100" height="4" rx="1" fill="#9197A0" opacity="0.5" />
            </g>
        </g>

        {/* Hands Typing */}
        <circle cx="160" cy="240" r="12" fill="#D3D6D9" className="animate-type-left" />
        <circle cx="240" cy="240" r="12" fill="#D3D6D9" className="animate-type-right" />

        {/* Reflection on Screen */}
        <path d="M100 80 L200 80 L150 210 L100 210 Z" fill="white" opacity="0.05" />

      </svg>
    </div>
  );
};

export default CodingIllustration;
