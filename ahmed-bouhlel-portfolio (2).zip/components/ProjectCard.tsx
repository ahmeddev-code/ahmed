
import React from 'react';
import { IconExternalLink } from './Icons';

const ProjectCard = ({ project }) => {
  return (
    <div className="group relative bg-white/40 backdrop-blur-xl rounded-[2rem] border border-white/60 overflow-hidden hover:shadow-2xl hover:shadow-scientific-500/10 hover:border-white/90 transition-all duration-500 flex flex-col h-full transform hover:-translate-y-2">
      <div className="h-64 overflow-hidden relative p-3">
        <div className="w-full h-full rounded-[1.5rem] overflow-hidden relative shadow-inner">
          <img 
            src={project.imageUrl} 
            alt={project.title} 
            className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-shark-900/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        </div>
      </div>
      
      <div className="px-6 pb-8 pt-2 flex-1 flex flex-col">
        <div className="flex justify-between items-start mb-3">
            <h3 className="text-xl font-bold text-black group-hover:text-scientific-600 transition-colors">{project.title}</h3>
            {project.link && (
                <a href={project.link} target="_blank" rel="noopener noreferrer" className="p-3 bg-white/40 backdrop-blur-xl border border-white/60 rounded-full text-shark-600 hover:text-scientific-600 hover:bg-white/70 hover:border-white/80 transition-all shadow-sm hover:shadow-md group-hover:scale-110">
                    <IconExternalLink className="w-4 h-4" />
                </a>
            )}
        </div>
        <p className="text-shark-600 text-sm leading-relaxed mb-6 flex-1 font-medium">
          {project.description}
        </p>
        
        <div className="flex flex-wrap gap-2 mt-auto">
          {project.tags.map((tag) => (
            <span 
              key={tag} 
              className="px-3 py-1 bg-white/30 backdrop-blur-md text-shark-600 text-xs font-bold rounded-full border border-white/40 group-hover:border-scientific-200 group-hover:bg-scientific-50/40 group-hover:text-scientific-700 transition-colors"
            >
              {tag}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProjectCard;
