import React, { useState, useRef, useEffect } from 'react';
import { IconMessage, IconSend, IconX, IconSparkles } from './Icons';
import { generateChatResponseStream } from '../services/geminiService';

interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  isError?: boolean;
}

const GeminiChat = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: "Hi there! I'm Ahmed's AI assistant. Ask me anything about his work or skills." }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsLoading(true);

    try {
      // Prepare history for the API (excluding the latest user message which is sent as 'message')
      const history = messages.map(m => ({
        role: m.role === 'user' ? 'user' : 'model',
        parts: [{ text: m.text }]
      }));

      const streamResult = await generateChatResponseStream(history, userMessage);
      
      let fullResponse = "";
      setMessages(prev => [...prev, { role: 'model', text: "" }]); // Add placeholder

      for await (const chunk of streamResult) {
        const chunkText = chunk.text || "";
        fullResponse += chunkText;
        
        setMessages(prev => {
          const newMessages = [...prev];
          newMessages[newMessages.length - 1].text = fullResponse;
          return newMessages;
        });
      }
    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', text: "Sorry, I'm having trouble connecting right now. Please try again later.", isError: true }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {/* Chat Window */}
      {isOpen && (
        <div className="mb-4 w-[360px] h-[500px] bg-white/60 backdrop-blur-2xl rounded-4xl shadow-2xl border border-white/50 flex flex-col overflow-hidden transition-all duration-300 origin-bottom-right ring-1 ring-white/30">
          {/* Header */}
          <div className="bg-white/20 backdrop-blur-lg p-5 text-black flex justify-between items-center border-b border-white/30">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-scientific-500/20 rounded-full backdrop-blur-sm border border-scientific-200/30">
                <IconSparkles className="w-5 h-5 text-scientific-600" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-black">AI Assistant</h3>
                <p className="text-xs text-shark-500">Powered by Gemini 2.5</p>
              </div>
            </div>
            <button 
              onClick={() => setIsOpen(false)}
              className="p-1.5 hover:bg-white/40 rounded-full transition-colors backdrop-blur-sm"
            >
              <IconX className="w-5 h-5 text-shark-500" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((msg, idx) => (
              <div 
                key={idx} 
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div 
                  className={`max-w-[85%] p-3.5 text-sm leading-relaxed rounded-2xl backdrop-blur-md shadow-sm ${
                    msg.role === 'user' 
                      ? 'bg-scientific-600/90 text-white rounded-tr-none border border-scientific-500/30' 
                      : 'bg-white/50 border border-white/60 text-shark-800 rounded-tl-none'
                  } ${msg.isError ? 'bg-red-50/80 text-red-600 border-red-200' : ''}`}
                >
                  {msg.text}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 bg-white/40 backdrop-blur-xl border-t border-white/40">
            <div className="flex items-center gap-2 bg-white/50 border border-white/60 rounded-full px-4 py-2 focus-within:ring-2 focus-within:ring-scientific-500/20 transition-all shadow-inner">
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask about my projects..."
                className="flex-1 bg-transparent border-none outline-none text-sm text-black placeholder-shark-400"
                disabled={isLoading}
              />
              <button 
                onClick={handleSend}
                disabled={isLoading || !input.trim()}
                className={`p-2 rounded-full transition-all backdrop-blur-md ${
                  input.trim() && !isLoading 
                    ? 'bg-scientific-600/90 text-white shadow-lg hover:bg-scientific-600' 
                    : 'bg-shark-400/20 text-shark-400'
                }`}
              >
                <IconSend className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`group h-14 w-14 flex items-center justify-center rounded-full shadow-2xl border border-white/20 backdrop-blur-xl transition-all duration-300 hover:scale-110 ${
            isOpen 
              ? 'bg-shark-900/80 rotate-90 text-white' 
              : 'bg-scientific-600/90 text-white hover:bg-scientific-50/90'
        }`}
      >
        {isOpen ? (
           <IconX className="w-6 h-6" />
        ) : (
          <IconMessage className="w-6 h-6" />
        )}
      </button>
    </div>
  );
};

export default GeminiChat;