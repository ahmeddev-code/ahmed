
import React, { useState, useEffect } from 'react';
import { IconGithub, IconTwitter, IconLinkedin, IconExternalLink, IconDownload, IconFile } from './components/Icons';
import GeminiChat from './components/GeminiChat';
import ProjectCard from './components/ProjectCard';
import CodingIllustration from './components/CodingIllustration';
import { SectionId } from './types';

// Sample Data
const PROJECTS = [
  {
    id: '1',
    title: 'Nebula Analytics',
    description: 'A real-time data visualization dashboard for SaaS metrics using D3.js and WebGL.',
    tags: ['React', 'D3.js', 'WebGL', 'JavaScript'],
    imageUrl: 'https://picsum.photos/600/400?random=1',
    link: '#'
  },
  {
    id: '2',
    title: 'Echo AI Interface',
    description: 'Conversational interface built with Gemini API featuring streaming responses and multi-modal input.',
    tags: ['Gemini API', 'Next.js', 'Tailwind', 'Vercel AI'],
    imageUrl: 'https://picsum.photos/600/400?random=2',
    link: '#'
  },
  {
    id: '3',
    title: 'Flux Commerce',
    description: 'High-performance headless e-commerce storefront with optimistic UI updates.',
    tags: ['React', 'Shopify Storefront', 'GraphQL'],
    imageUrl: 'https://picsum.photos/600/400?random=3',
    link: '#'
  }
];

const DOWNLOADS = [
  {
    id: '1',
    title: 'My Resume / CV',
    description: 'Detailed PDF summary of my professional experience and education.',
    format: 'PDF',
    size: '2.4 MB'
  },
  {
    id: '2',
    title: 'Nebula Case Study',
    description: 'In-depth breakdown of the architecture behind the Nebula dashboard.',
    format: 'PDF',
    size: '12 MB'
  },
  {
    id: '3',
    title: 'Design System Kit',
    description: 'The Figma library used to design this portfolio and other projects.',
    format: 'FIG',
    size: '45 MB'
  }
];

function App() {
  const [activeSection, setActiveSection] = useState(SectionId.HOME);

  // Sticky header logic
  const [isScrolled, setIsScrolled] = useState(false);
  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinkClass = (id) => 
    `px-5 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
      activeSection === id 
        ? 'bg-shark-900/50 backdrop-blur-xl text-white shadow-lg border border-shark-800/20' 
        : 'text-shark-500 hover:bg-white/20 hover:backdrop-blur-lg hover:text-black'
    }`;

  return (
    <div className="min-h-screen bg-athenian-200 text-black selection:bg-scientific-200 selection:text-scientific-900 font-sans overflow-x-hidden relative">
      
      {/* Background Ambience */}
      <div className="fixed inset-0 -z-10 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[50vw] h-[50vw] rounded-full bg-scientific-100/40 blur-[120px] opacity-50 mix-blend-multiply animate-float" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50vw] h-[50vw] rounded-full bg-athenian-50/40 blur-[120px] opacity-60 mix-blend-multiply animate-float delay-300" />
        <div className="absolute top-[40%] left-[40%] w-[30vw] h-[30vw] rounded-full bg-white/60 blur-[80px] opacity-70" />
      </div>

      {/* Navigation */}
      <nav className={`fixed top-0 inset-x-0 z-40 transition-all duration-500 ease-in-out ${isScrolled ? 'bg-white/20 backdrop-blur-xl border-b border-white/20 py-3 shadow-sm' : 'bg-transparent py-6'}`}>
        <div className="container mx-auto px-6 flex items-center justify-between">
          <div className="text-2xl font-extrabold tracking-tight text-black">
            Ahmed<span className="text-scientific-500">.</span>
          </div>
          <div className="hidden md:flex gap-1.5 bg-white/10 p-1.5 rounded-full border border-white/20 backdrop-blur-xl shadow-sm">
            {Object.values(SectionId).map((id) => (
              <button 
                key={id} 
                onClick={() => {
                  setActiveSection(id);
                  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
                }}
                className={navLinkClass(id)}
              >
                {id.charAt(0).toUpperCase() + id.slice(1)}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
             <button className="p-2.5 rounded-full bg-white/20 backdrop-blur-xl border border-white/30 text-shark-500 hover:text-black hover:border-white/50 hover:bg-white/40 hover:shadow-lg transition-all"><IconGithub className="w-5 h-5" /></button>
             <button className="p-2.5 rounded-full bg-white/20 backdrop-blur-xl border border-white/30 text-shark-500 hover:text-scientific-400 hover:border-scientific-200 hover:bg-white/40 hover:shadow-lg transition-all"><IconTwitter className="w-5 h-5" /></button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id={SectionId.HOME} className="pt-36 pb-24 lg:pt-40 lg:pb-32 container mx-auto px-6 relative z-10">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
          
          {/* Hero Text */}
          <div className="flex-1 text-center lg:text-left">
            <div className="inline-flex items-center gap-2.5 px-5 py-2.5 rounded-full bg-white/30 backdrop-blur-xl border border-white/40 text-scientific-800 font-bold text-sm mb-10 animate-fade-in-up shadow-sm ring-1 ring-white/50">
                <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-scientific-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-scientific-500"></span>
                </span>
                Available for new projects
            </div>
            
            <h1 className="animate-fade-in-up delay-100 text-6xl md:text-7xl lg:text-8xl font-extrabold tracking-tight text-black mb-10 leading-[1.05]">
                Crafting <span className="text-transparent bg-clip-text bg-gradient-to-br from-scientific-600 to-scientific-400 inline-block animate-float">polished</span> digital experiences.
            </h1>
            
            <p className="animate-fade-in-up delay-200 text-xl md:text-2xl text-shark-500 max-w-2xl mx-auto lg:mx-0 mb-12 leading-relaxed font-medium">
                Senior Frontend Engineer focused on building beautiful, accessible, and performant web applications.
            </p>
            
            <div className="animate-fade-in-up delay-300 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
                <button 
                    onClick={() => document.getElementById(SectionId.PROJECTS)?.scrollIntoView({ behavior: 'smooth' })}
                    className="w-full sm:w-auto px-8 py-4 bg-scientific-500/80 backdrop-blur-2xl border border-scientific-400/30 text-white font-bold text-lg rounded-full hover:bg-scientific-600 transition-all shadow-2xl shadow-scientific-500/20 hover:shadow-scientific-500/40 hover:-translate-y-1"
                >
                <span className="text-white">View Work</span>
                </button>
                <button 
                    onClick={() => document.getElementById(SectionId.RESOURCES)?.scrollIntoView({ behavior: 'smooth' })}
                    className="w-full sm:w-auto px-8 py-4 bg-white/30 backdrop-blur-2xl text-shark-900 border border-white/50 rounded-full font-bold text-lg hover:bg-white/50 hover:border-white/70 transition-all shadow-lg shadow-shark-200/10 hover:shadow-xl"
                >
                Downloads
                </button>
            </div>
          </div>

          {/* Hero Illustration */}
          <div className="flex-1 w-full max-w-md lg:max-w-xl animate-fade-in-up delay-300">
             <div className="relative bg-white/20 backdrop-blur-xl rounded-[3rem] p-8 border border-white/40 shadow-2xl shadow-scientific-500/10">
                <CodingIllustration />
             </div>
          </div>

        </div>
      </section>

      {/* Projects Section */}
      <section id={SectionId.PROJECTS} className="py-32 relative z-10">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-6">
            <div className="max-w-xl">
               <h2 className="text-4xl font-bold mb-6 text-black">Featured Projects</h2>
               <p className="text-shark-500 text-lg font-medium">A selection of work that demonstrates my ability to solve complex problems with elegant solutions.</p>
            </div>
            <a href="#" className="group flex items-center gap-2 px-6 py-3 bg-white/30 backdrop-blur-xl border border-white/40 rounded-full text-shark-600 font-bold text-sm hover:bg-white/60 hover:text-scientific-700 hover:border-white/60 transition-all shadow-sm hover:shadow-md">
              View all archives <IconExternalLink className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
            </a>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-10">
            {PROJECTS.map(project => (
              <ProjectCard key={project.id} project={project} />
            ))}
          </div>
        </div>
      </section>

      {/* Resources / Downloads Section */}
      <section id={SectionId.RESOURCES} className="py-32 mx-4 md:mx-8 relative z-10">
        <div className="absolute inset-0 bg-white/30 backdrop-blur-lg rounded-[3rem] md:rounded-[4rem] border border-white/40 -z-10 shadow-xl shadow-shark-200/10"></div>
        <div className="container mx-auto px-6 md:px-12">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-4xl font-bold mb-6 text-black">Downloads & Resources</h2>
            <p className="text-shark-500 text-lg font-medium">
              Detailed documents and assets available for download to learn more about my process and work.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {DOWNLOADS.map((item) => (
              <div key={item.id} className="group p-8 bg-white/30 backdrop-blur-xl rounded-[2.5rem] border border-white/50 hover:border-scientific-200 hover:bg-white/60 hover:shadow-2xl hover:shadow-scientific-500/10 transition-all duration-500 flex flex-col items-start hover:-translate-y-1">
                <div className="p-4 bg-white/40 rounded-2xl border border-white/40 mb-6 shadow-sm group-hover:bg-scientific-50/60 group-hover:border-scientific-100/60 transition-colors backdrop-blur-md">
                  <IconFile className="w-8 h-8 text-shark-400 group-hover:text-scientific-500 transition-colors" />
                </div>
                <h3 className="text-xl font-bold text-black mb-2">{item.title}</h3>
                <p className="text-shark-500 text-sm mb-8 flex-1 font-medium">{item.description}</p>
                
                <div className="w-full flex items-center justify-between pt-6 border-t border-shark-900/5 group-hover:border-scientific-100 transition-colors">
                   <span className="text-xs font-bold text-shark-400 uppercase tracking-wider">{item.format} • {item.size}</span>
                   <button className="p-3 rounded-full bg-white/40 backdrop-blur-xl border border-white/50 text-shark-600 hover:bg-scientific-600 hover:text-white hover:border-scientific-600 transition-all shadow-sm hover:shadow-md group-hover:scale-110">
                     <IconDownload className="w-5 h-5" />
                   </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id={SectionId.CONTACT} className="py-32 relative overflow-hidden">
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl mx-auto bg-shark-900/95 backdrop-blur-2xl rounded-[3rem] p-10 md:p-20 text-center text-white shadow-2xl shadow-shark-900/20 border border-shark-800">
            <h2 className="text-4xl md:text-6xl font-bold mb-8 text-white">Ready to start a project?</h2>
            <p className="text-shark-300 text-xl mb-12 max-w-2xl mx-auto leading-relaxed">
              I'm currently accepting new freelance opportunities. If you have a project in mind, let's discuss how we can work together.
            </p>
            <button className="px-12 py-5 bg-white/10 backdrop-blur-xl border border-white/10 text-white rounded-full text-lg font-bold hover:bg-white/20 transition-colors shadow-2xl hover:scale-105 duration-300 ring-1 ring-white/5">
              Say Hello
            </button>
            <div className="mt-16 flex flex-wrap justify-center gap-8 md:gap-12 text-shark-400 font-medium">
                <a href="#" className="hover:text-white transition-colors flex items-center gap-3"><IconGithub className="w-6 h-6"/> GitHub</a>
                <a href="#" className="hover:text-white transition-colors flex items-center gap-3"><IconLinkedin className="w-6 h-6"/> LinkedIn</a>
                <a href="#" className="hover:text-white transition-colors flex items-center gap-3"><IconTwitter className="w-6 h-6"/> Twitter</a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-10 bg-transparent text-center text-shark-500 text-sm font-medium border-t border-shark-200/50">
        <p>&copy; {new Date().getFullYear()} Ahmed Bouhlel. Built with React, Tailwind & Gemini API.</p>
      </footer>

      {/* Floating Chat Widget */}
      <GeminiChat />
    </div>
  );
}

export default App;
