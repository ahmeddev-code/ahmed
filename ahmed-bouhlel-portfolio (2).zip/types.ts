
export const SectionId = {
  HOME: 'home',
  PROJECTS: 'projects',
  RESOURCES: 'resources',
  CONTACT: 'contact',
};
