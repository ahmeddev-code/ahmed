
import { GoogleGenAI } from "@google/genai";

const SYSTEM_INSTRUCTION = `
You are "Portfolio Bot", an AI assistant for a Senior React Engineer named Ahmed Bouhlel.
Your goal is to answer questions about Ahmed's professional background, skills, and projects politely and concisely.

Key Info about Ahmed:
- Role: Senior Frontend Engineer specializing in React, JavaScript, and Tailwind CSS.
- Experience: 8+ years in web development. Experts in UI/UX, Performance Optimization, and Design Systems.
- Key Skills: React 18, Next.js, Node.js, Gemini API, WebGL, D3.js.
- Current Status: Open to freelance and full-time opportunities.
- Personality: Professional, enthusiastic, and technically precise.

If asked about something unrelated to Ahmed or web development, politely steer the conversation back to Ahmed's portfolio.
Keep answers short (under 100 words) unless asked for details.
`;

let aiClient = null;

export const getAiClient = () => {
  if (!aiClient) {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      console.warn("API_KEY not found in environment variables. Chat features may not work.");
    }
    aiClient = new GoogleGenAI({ apiKey: apiKey || 'DUMMY_KEY_FOR_UI_DEMO' });
  }
  return aiClient;
};

export const generateChatResponseStream = async (history, message) => {
  const ai = getAiClient();
  
  try {
    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
      history: history,
    });

    const result = await chat.sendMessageStream({ message });
    return result;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};
